﻿Public Class Login

    Private Sub ChkPassword_CheckedChanged(sender As Object, e As EventArgs) Handles ChkPassword.CheckedChanged

    End Sub

    
    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click

        'LOGIN CODE

        If TxtUsername.Text = "" Or TxtPassword.Text = "" Then
            MessageBox.Show("Incorrect Password Or Username", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        ElseIf TxtUsername.Text = "lihle" And TxtPassword.Text = "1234" Then
            TxtUsername.ForeColor = Color.Green
            TxtPassword.ForeColor = Color.Green

            MessageBox.Show("Access Granted", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information)

            'Displays Home Table
            Me.Hide()
            Dim Main = New MainMenu
            MainMenu.Show()
        Else

            MessageBox.Show("Wrong Password Or Username", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            TxtUsername.ForeColor = Color.Red
            TxtPassword.ForeColor = Color.Red
           
        End If

    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        TxtUsername.Text = ""
        TxtPassword.Text = ""

    End Sub
End Class
﻿Public Class SplashScreen

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        GunaCircleProgressBar1.Increment(1)
        If GunaCircleProgressBar1.Value = 100 Then
            Me.Hide()
            Dim log = New LoginForm
            LoginForm.Show()

            Timer1.Enabled = False
        End If

    End Sub

    Private Sub SplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()

    End Sub

End Class
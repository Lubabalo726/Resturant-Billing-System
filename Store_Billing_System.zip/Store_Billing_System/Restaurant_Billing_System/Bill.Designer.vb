﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Bill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Bill))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.LblItemTotal = New System.Windows.Forms.Label()
        Me.lblNumOfItems = New System.Windows.Forms.Label()
        Me.LblTotalCost = New System.Windows.Forms.Label()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnReceipt = New System.Windows.Forms.Button()
        Me.BtnTotal = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BtnPrint = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.NumericMilk = New System.Windows.Forms.NumericUpDown()
        Me.NumericSoup = New System.Windows.Forms.NumericUpDown()
        Me.LblSoup = New System.Windows.Forms.Label()
        Me.LblItemSoup = New System.Windows.Forms.Label()
        Me.NumericPotato = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.LblItemMilk = New System.Windows.Forms.Label()
        Me.LblMilk = New System.Windows.Forms.Label()
        Me.LblPotato = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LblItemMeat = New System.Windows.Forms.Label()
        Me.LblMeat = New System.Windows.Forms.Label()
        Me.NumericFlour = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LblItemFlour = New System.Windows.Forms.Label()
        Me.NumericMeat = New System.Windows.Forms.NumericUpDown()
        Me.LblFlour = New System.Windows.Forms.Label()
        Me.LblItemPotato = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LblItemBread = New System.Windows.Forms.Label()
        Me.NumericBeans = New System.Windows.Forms.NumericUpDown()
        Me.LblBread = New System.Windows.Forms.Label()
        Me.LblBeans = New System.Windows.Forms.Label()
        Me.LblItemBeans = New System.Windows.Forms.Label()
        Me.NumericBread = New System.Windows.Forms.NumericUpDown()
        Me.NumericNyala = New System.Windows.Forms.NumericUpDown()
        Me.LblItemOil = New System.Windows.Forms.Label()
        Me.LblNyala = New System.Windows.Forms.Label()
        Me.LblOil = New System.Windows.Forms.Label()
        Me.LblItemNyala = New System.Windows.Forms.Label()
        Me.NumericOil = New System.Windows.Forms.NumericUpDown()
        Me.NumericRice = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LblRice = New System.Windows.Forms.Label()
        Me.LblItemRice = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BtnOn = New System.Windows.Forms.Button()
        Me.btnOff = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Panel1.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel8.SuspendLayout()
        CType(Me.NumericMilk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericSoup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericPotato, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericFlour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericMeat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.NumericBeans, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericBread, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericNyala, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericOil, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericRice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Panel9)
        Me.Panel1.Controls.Add(Me.RichTextBox1)
        Me.Panel1.Location = New System.Drawing.Point(790, 72)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(395, 453)
        Me.Panel1.TabIndex = 0
        '
        'Panel9
        '
        Me.Panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel9.Controls.Add(Me.Label2)
        Me.Panel9.Location = New System.Drawing.Point(13, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(364, 65)
        Me.Panel9.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(71, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(195, 25)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = " COST OF ITEMS"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(13, 74)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(364, 359)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.LblItemTotal)
        Me.Panel3.Controls.Add(Me.lblNumOfItems)
        Me.Panel3.Controls.Add(Me.LblTotalCost)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 537)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1197, 64)
        Me.Panel3.TabIndex = 2
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(103, 16)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(75, 25)
        Me.Label21.TabIndex = 39
        Me.Label21.Text = " Items"
        '
        'LblItemTotal
        '
        Me.LblItemTotal.AutoSize = True
        Me.LblItemTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemTotal.Location = New System.Drawing.Point(295, 16)
        Me.LblItemTotal.Name = "LblItemTotal"
        Me.LblItemTotal.Size = New System.Drawing.Size(127, 25)
        Me.LblItemTotal.TabIndex = 39
        Me.LblItemTotal.Text = "Total Cost:"
        '
        'lblNumOfItems
        '
        Me.lblNumOfItems.BackColor = System.Drawing.Color.White
        Me.lblNumOfItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNumOfItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumOfItems.Location = New System.Drawing.Point(187, 13)
        Me.lblNumOfItems.Name = "lblNumOfItems"
        Me.lblNumOfItems.Size = New System.Drawing.Size(96, 32)
        Me.lblNumOfItems.TabIndex = 39
        Me.lblNumOfItems.Text = "0"
        Me.lblNumOfItems.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblTotalCost
        '
        Me.LblTotalCost.BackColor = System.Drawing.Color.White
        Me.LblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblTotalCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotalCost.Location = New System.Drawing.Point(425, 13)
        Me.LblTotalCost.Name = "LblTotalCost"
        Me.LblTotalCost.Size = New System.Drawing.Size(119, 32)
        Me.LblTotalCost.TabIndex = 39
        Me.LblTotalCost.Text = "R0.00"
        Me.LblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnExit
        '
        Me.BtnExit.BackColor = System.Drawing.Color.Lime
        Me.BtnExit.FlatAppearance.BorderSize = 0
        Me.BtnExit.Location = New System.Drawing.Point(4, 207)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(71, 32)
        Me.BtnExit.TabIndex = 1
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'BtnReceipt
        '
        Me.BtnReceipt.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnReceipt.FlatAppearance.BorderSize = 2
        Me.BtnReceipt.Location = New System.Drawing.Point(514, 414)
        Me.BtnReceipt.Name = "BtnReceipt"
        Me.BtnReceipt.Size = New System.Drawing.Size(102, 32)
        Me.BtnReceipt.TabIndex = 0
        Me.BtnReceipt.Text = "Receipt"
        Me.BtnReceipt.UseVisualStyleBackColor = False
        '
        'BtnTotal
        '
        Me.BtnTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnTotal.FlatAppearance.BorderSize = 0
        Me.BtnTotal.Location = New System.Drawing.Point(395, 414)
        Me.BtnTotal.Name = "BtnTotal"
        Me.BtnTotal.Size = New System.Drawing.Size(101, 32)
        Me.BtnTotal.TabIndex = 3
        Me.BtnTotal.Text = "Total"
        Me.BtnTotal.UseVisualStyleBackColor = False
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.Yellow
        Me.BtnReset.FlatAppearance.BorderSize = 0
        Me.BtnReset.Location = New System.Drawing.Point(4, 153)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(71, 32)
        Me.BtnReset.TabIndex = 2
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Controls.Add(Me.Label13)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1197, 66)
        Me.Panel4.TabIndex = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(81, 56)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(239, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 25)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "LogOut"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Elephant", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(466, 12)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(236, 38)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Billing System "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1153, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "X"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.BtnPrint)
        Me.Panel2.Controls.Add(Me.Panel8)
        Me.Panel2.Controls.Add(Me.Panel7)
        Me.Panel2.Controls.Add(Me.BtnReceipt)
        Me.Panel2.Controls.Add(Me.BtnTotal)
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Controls.Add(Me.Panel5)
        Me.Panel2.Location = New System.Drawing.Point(0, 72)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(784, 453)
        Me.Panel2.TabIndex = 1
        '
        'BtnPrint
        '
        Me.BtnPrint.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnPrint.FlatAppearance.BorderSize = 0
        Me.BtnPrint.Location = New System.Drawing.Point(640, 414)
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Size = New System.Drawing.Size(123, 32)
        Me.BtnPrint.TabIndex = 6
        Me.BtnPrint.Text = "Print"
        Me.BtnPrint.UseVisualStyleBackColor = False
        '
        'Panel8
        '
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel8.Controls.Add(Me.NumericMilk)
        Me.Panel8.Controls.Add(Me.NumericSoup)
        Me.Panel8.Controls.Add(Me.LblSoup)
        Me.Panel8.Controls.Add(Me.LblItemSoup)
        Me.Panel8.Controls.Add(Me.NumericPotato)
        Me.Panel8.Controls.Add(Me.Label12)
        Me.Panel8.Controls.Add(Me.LblItemMilk)
        Me.Panel8.Controls.Add(Me.LblMilk)
        Me.Panel8.Controls.Add(Me.LblPotato)
        Me.Panel8.Controls.Add(Me.Label9)
        Me.Panel8.Controls.Add(Me.LblItemMeat)
        Me.Panel8.Controls.Add(Me.LblMeat)
        Me.Panel8.Controls.Add(Me.NumericFlour)
        Me.Panel8.Controls.Add(Me.Label5)
        Me.Panel8.Controls.Add(Me.LblItemFlour)
        Me.Panel8.Controls.Add(Me.NumericMeat)
        Me.Panel8.Controls.Add(Me.LblFlour)
        Me.Panel8.Controls.Add(Me.LblItemPotato)
        Me.Panel8.Location = New System.Drawing.Point(473, 18)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(306, 392)
        Me.Panel8.TabIndex = 44
        '
        'NumericMilk
        '
        Me.NumericMilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericMilk.Location = New System.Drawing.Point(80, 138)
        Me.NumericMilk.Name = "NumericMilk"
        Me.NumericMilk.Size = New System.Drawing.Size(85, 31)
        Me.NumericMilk.TabIndex = 21
        Me.NumericMilk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericSoup
        '
        Me.NumericSoup.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericSoup.Location = New System.Drawing.Point(80, 71)
        Me.NumericSoup.Name = "NumericSoup"
        Me.NumericSoup.Size = New System.Drawing.Size(85, 31)
        Me.NumericSoup.TabIndex = 19
        Me.NumericSoup.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LblSoup
        '
        Me.LblSoup.BackColor = System.Drawing.Color.White
        Me.LblSoup.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblSoup.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSoup.Location = New System.Drawing.Point(192, 73)
        Me.LblSoup.Name = "LblSoup"
        Me.LblSoup.Size = New System.Drawing.Size(96, 32)
        Me.LblSoup.TabIndex = 18
        Me.LblSoup.Text = "R0.00"
        Me.LblSoup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblItemSoup
        '
        Me.LblItemSoup.AutoSize = True
        Me.LblItemSoup.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemSoup.Location = New System.Drawing.Point(8, 73)
        Me.LblItemSoup.Name = "LblItemSoup"
        Me.LblItemSoup.Size = New System.Drawing.Size(66, 25)
        Me.LblItemSoup.TabIndex = 28
        Me.LblItemSoup.Text = "Soup"
        '
        'NumericPotato
        '
        Me.NumericPotato.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericPotato.Location = New System.Drawing.Point(80, 337)
        Me.NumericPotato.Name = "NumericPotato"
        Me.NumericPotato.Size = New System.Drawing.Size(85, 31)
        Me.NumericPotato.TabIndex = 27
        Me.NumericPotato.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(75, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(93, 25)
        Me.Label12.TabIndex = 39
        Me.Label12.Text = "Number"
        '
        'LblItemMilk
        '
        Me.LblItemMilk.AutoSize = True
        Me.LblItemMilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemMilk.Location = New System.Drawing.Point(8, 140)
        Me.LblItemMilk.Name = "LblItemMilk"
        Me.LblItemMilk.Size = New System.Drawing.Size(55, 25)
        Me.LblItemMilk.TabIndex = 29
        Me.LblItemMilk.Text = "Milk"
        '
        'LblMilk
        '
        Me.LblMilk.BackColor = System.Drawing.Color.White
        Me.LblMilk.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblMilk.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMilk.Location = New System.Drawing.Point(192, 138)
        Me.LblMilk.Name = "LblMilk"
        Me.LblMilk.Size = New System.Drawing.Size(96, 32)
        Me.LblMilk.TabIndex = 20
        Me.LblMilk.Text = "R0.00"
        Me.LblMilk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblPotato
        '
        Me.LblPotato.BackColor = System.Drawing.Color.White
        Me.LblPotato.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblPotato.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPotato.Location = New System.Drawing.Point(192, 336)
        Me.LblPotato.Name = "LblPotato"
        Me.LblPotato.Size = New System.Drawing.Size(96, 32)
        Me.LblPotato.TabIndex = 26
        Me.LblPotato.Text = "R0.00"
        Me.LblPotato.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(181, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 25)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Cost Price"
        '
        'LblItemMeat
        '
        Me.LblItemMeat.AutoSize = True
        Me.LblItemMeat.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemMeat.Location = New System.Drawing.Point(10, 208)
        Me.LblItemMeat.Name = "LblItemMeat"
        Me.LblItemMeat.Size = New System.Drawing.Size(64, 25)
        Me.LblItemMeat.TabIndex = 30
        Me.LblItemMeat.Text = "Meat"
        '
        'LblMeat
        '
        Me.LblMeat.BackColor = System.Drawing.Color.White
        Me.LblMeat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblMeat.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMeat.Location = New System.Drawing.Point(192, 201)
        Me.LblMeat.Name = "LblMeat"
        Me.LblMeat.Size = New System.Drawing.Size(96, 32)
        Me.LblMeat.TabIndex = 22
        Me.LblMeat.Text = "R0.00"
        Me.LblMeat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericFlour
        '
        Me.NumericFlour.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericFlour.Location = New System.Drawing.Point(80, 266)
        Me.NumericFlour.Name = "NumericFlour"
        Me.NumericFlour.Size = New System.Drawing.Size(85, 31)
        Me.NumericFlour.TabIndex = 25
        Me.NumericFlour.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(-7, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 25)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = " Items"
        '
        'LblItemFlour
        '
        Me.LblItemFlour.AutoSize = True
        Me.LblItemFlour.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemFlour.Location = New System.Drawing.Point(8, 269)
        Me.LblItemFlour.Name = "LblItemFlour"
        Me.LblItemFlour.Size = New System.Drawing.Size(66, 25)
        Me.LblItemFlour.TabIndex = 31
        Me.LblItemFlour.Text = "Flour"
        '
        'NumericMeat
        '
        Me.NumericMeat.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericMeat.Location = New System.Drawing.Point(80, 201)
        Me.NumericMeat.Name = "NumericMeat"
        Me.NumericMeat.Size = New System.Drawing.Size(85, 31)
        Me.NumericMeat.TabIndex = 23
        Me.NumericMeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LblFlour
        '
        Me.LblFlour.BackColor = System.Drawing.Color.White
        Me.LblFlour.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblFlour.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblFlour.Location = New System.Drawing.Point(192, 266)
        Me.LblFlour.Name = "LblFlour"
        Me.LblFlour.Size = New System.Drawing.Size(96, 32)
        Me.LblFlour.TabIndex = 24
        Me.LblFlour.Text = "R0.00"
        Me.LblFlour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblItemPotato
        '
        Me.LblItemPotato.AutoSize = True
        Me.LblItemPotato.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemPotato.Location = New System.Drawing.Point(3, 342)
        Me.LblItemPotato.Name = "LblItemPotato"
        Me.LblItemPotato.Size = New System.Drawing.Size(80, 25)
        Me.LblItemPotato.TabIndex = 32
        Me.LblItemPotato.Text = "Potato"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel7.Controls.Add(Me.Label7)
        Me.Panel7.Controls.Add(Me.Label11)
        Me.Panel7.Controls.Add(Me.LblItemBread)
        Me.Panel7.Controls.Add(Me.NumericBeans)
        Me.Panel7.Controls.Add(Me.LblBread)
        Me.Panel7.Controls.Add(Me.LblBeans)
        Me.Panel7.Controls.Add(Me.LblItemBeans)
        Me.Panel7.Controls.Add(Me.NumericBread)
        Me.Panel7.Controls.Add(Me.NumericNyala)
        Me.Panel7.Controls.Add(Me.LblItemOil)
        Me.Panel7.Controls.Add(Me.LblNyala)
        Me.Panel7.Controls.Add(Me.LblOil)
        Me.Panel7.Controls.Add(Me.LblItemNyala)
        Me.Panel7.Controls.Add(Me.NumericOil)
        Me.Panel7.Controls.Add(Me.NumericRice)
        Me.Panel7.Controls.Add(Me.Label3)
        Me.Panel7.Controls.Add(Me.LblRice)
        Me.Panel7.Controls.Add(Me.LblItemRice)
        Me.Panel7.Location = New System.Drawing.Point(100, 18)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(345, 392)
        Me.Panel7.TabIndex = 43
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(219, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 25)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "Cost Price"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(94, 20)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 25)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Number"
        '
        'LblItemBread
        '
        Me.LblItemBread.AutoSize = True
        Me.LblItemBread.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemBread.Location = New System.Drawing.Point(13, 71)
        Me.LblItemBread.Name = "LblItemBread"
        Me.LblItemBread.Size = New System.Drawing.Size(74, 25)
        Me.LblItemBread.TabIndex = 3
        Me.LblItemBread.Text = "Bread"
        '
        'NumericBeans
        '
        Me.NumericBeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericBeans.Location = New System.Drawing.Point(99, 335)
        Me.NumericBeans.Name = "NumericBeans"
        Me.NumericBeans.Size = New System.Drawing.Size(98, 31)
        Me.NumericBeans.TabIndex = 17
        Me.NumericBeans.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LblBread
        '
        Me.LblBread.BackColor = System.Drawing.Color.White
        Me.LblBread.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblBread.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBread.Location = New System.Drawing.Point(224, 71)
        Me.LblBread.Name = "LblBread"
        Me.LblBread.Size = New System.Drawing.Size(96, 32)
        Me.LblBread.TabIndex = 4
        Me.LblBread.Text = "R0.00"
        Me.LblBread.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblBeans
        '
        Me.LblBeans.BackColor = System.Drawing.Color.White
        Me.LblBeans.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblBeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBeans.Location = New System.Drawing.Point(224, 337)
        Me.LblBeans.Name = "LblBeans"
        Me.LblBeans.Size = New System.Drawing.Size(96, 32)
        Me.LblBeans.TabIndex = 16
        Me.LblBeans.Text = "R0.00"
        Me.LblBeans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblItemBeans
        '
        Me.LblItemBeans.AutoSize = True
        Me.LblItemBeans.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemBeans.Location = New System.Drawing.Point(15, 340)
        Me.LblItemBeans.Name = "LblItemBeans"
        Me.LblItemBeans.Size = New System.Drawing.Size(78, 25)
        Me.LblItemBeans.TabIndex = 15
        Me.LblItemBeans.Text = "Beans"
        '
        'NumericBread
        '
        Me.NumericBread.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericBread.Location = New System.Drawing.Point(99, 69)
        Me.NumericBread.Name = "NumericBread"
        Me.NumericBread.Size = New System.Drawing.Size(98, 31)
        Me.NumericBread.TabIndex = 5
        Me.NumericBread.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericNyala
        '
        Me.NumericNyala.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericNyala.Location = New System.Drawing.Point(99, 264)
        Me.NumericNyala.Name = "NumericNyala"
        Me.NumericNyala.Size = New System.Drawing.Size(98, 31)
        Me.NumericNyala.TabIndex = 14
        Me.NumericNyala.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LblItemOil
        '
        Me.LblItemOil.AutoSize = True
        Me.LblItemOil.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemOil.Location = New System.Drawing.Point(33, 136)
        Me.LblItemOil.Name = "LblItemOil"
        Me.LblItemOil.Size = New System.Drawing.Size(41, 25)
        Me.LblItemOil.TabIndex = 6
        Me.LblItemOil.Text = "Oil"
        '
        'LblNyala
        '
        Me.LblNyala.BackColor = System.Drawing.Color.White
        Me.LblNyala.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblNyala.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblNyala.Location = New System.Drawing.Point(224, 266)
        Me.LblNyala.Name = "LblNyala"
        Me.LblNyala.Size = New System.Drawing.Size(96, 32)
        Me.LblNyala.TabIndex = 13
        Me.LblNyala.Text = "R0.00"
        Me.LblNyala.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblOil
        '
        Me.LblOil.BackColor = System.Drawing.Color.White
        Me.LblOil.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblOil.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblOil.Location = New System.Drawing.Point(224, 138)
        Me.LblOil.Name = "LblOil"
        Me.LblOil.Size = New System.Drawing.Size(96, 32)
        Me.LblOil.TabIndex = 7
        Me.LblOil.Text = "R0.00"
        Me.LblOil.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblItemNyala
        '
        Me.LblItemNyala.AutoSize = True
        Me.LblItemNyala.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemNyala.Location = New System.Drawing.Point(15, 268)
        Me.LblItemNyala.Name = "LblItemNyala"
        Me.LblItemNyala.Size = New System.Drawing.Size(72, 25)
        Me.LblItemNyala.TabIndex = 12
        Me.LblItemNyala.Text = "Nyala"
        '
        'NumericOil
        '
        Me.NumericOil.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericOil.Location = New System.Drawing.Point(99, 136)
        Me.NumericOil.Name = "NumericOil"
        Me.NumericOil.Size = New System.Drawing.Size(98, 31)
        Me.NumericOil.TabIndex = 8
        Me.NumericOil.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericRice
        '
        Me.NumericRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericRice.Location = New System.Drawing.Point(99, 199)
        Me.NumericRice.Name = "NumericRice"
        Me.NumericRice.Size = New System.Drawing.Size(98, 31)
        Me.NumericRice.TabIndex = 11
        Me.NumericRice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(18, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 25)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = " Items"
        '
        'LblRice
        '
        Me.LblRice.BackColor = System.Drawing.Color.White
        Me.LblRice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRice.Location = New System.Drawing.Point(224, 201)
        Me.LblRice.Name = "LblRice"
        Me.LblRice.Size = New System.Drawing.Size(96, 32)
        Me.LblRice.TabIndex = 10
        Me.LblRice.Text = "R0.00"
        Me.LblRice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LblItemRice
        '
        Me.LblItemRice.AutoSize = True
        Me.LblItemRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemRice.Location = New System.Drawing.Point(15, 199)
        Me.LblItemRice.Name = "LblItemRice"
        Me.LblItemRice.Size = New System.Drawing.Size(59, 25)
        Me.LblItemRice.TabIndex = 9
        Me.LblItemRice.Text = "Rice"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Location = New System.Drawing.Point(451, 18)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(16, 392)
        Me.Panel6.TabIndex = 42
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.BtnOn)
        Me.Panel5.Controls.Add(Me.btnOff)
        Me.Panel5.Controls.Add(Me.BtnReset)
        Me.Panel5.Controls.Add(Me.BtnExit)
        Me.Panel5.Location = New System.Drawing.Point(12, 18)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(82, 280)
        Me.Panel5.TabIndex = 40
        '
        'BtnOn
        '
        Me.BtnOn.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnOn.FlatAppearance.BorderSize = 0
        Me.BtnOn.Location = New System.Drawing.Point(4, 38)
        Me.BtnOn.Name = "BtnOn"
        Me.BtnOn.Size = New System.Drawing.Size(71, 32)
        Me.BtnOn.TabIndex = 5
        Me.BtnOn.Text = "On"
        Me.BtnOn.UseVisualStyleBackColor = False
        '
        'btnOff
        '
        Me.btnOff.BackColor = System.Drawing.Color.Red
        Me.btnOff.FlatAppearance.BorderSize = 0
        Me.btnOff.Location = New System.Drawing.Point(4, 92)
        Me.btnOff.Name = "btnOff"
        Me.btnOff.Size = New System.Drawing.Size(71, 32)
        Me.btnOff.TabIndex = 4
        Me.btnOff.Text = "OFF"
        Me.btnOff.UseVisualStyleBackColor = False
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Bill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1197, 601)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Bill"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.Panel1.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        CType(Me.NumericMilk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericSoup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericPotato, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericFlour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericMeat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.NumericBeans, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericBread, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericNyala, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericOil, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericRice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents BtnReceipt As System.Windows.Forms.Button
    Friend WithEvents BtnTotal As System.Windows.Forms.Button
    Friend WithEvents BtnReset As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents LblBread As System.Windows.Forms.Label
    Friend WithEvents LblItemBread As System.Windows.Forms.Label
    Friend WithEvents NumericBread As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericBeans As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblBeans As System.Windows.Forms.Label
    Friend WithEvents LblItemBeans As System.Windows.Forms.Label
    Friend WithEvents NumericNyala As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblNyala As System.Windows.Forms.Label
    Friend WithEvents LblItemNyala As System.Windows.Forms.Label
    Friend WithEvents NumericRice As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblRice As System.Windows.Forms.Label
    Friend WithEvents LblItemRice As System.Windows.Forms.Label
    Friend WithEvents NumericOil As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblOil As System.Windows.Forms.Label
    Friend WithEvents LblItemOil As System.Windows.Forms.Label
    Friend WithEvents LblItemPotato As System.Windows.Forms.Label
    Friend WithEvents LblItemFlour As System.Windows.Forms.Label
    Friend WithEvents LblItemMeat As System.Windows.Forms.Label
    Friend WithEvents LblItemMilk As System.Windows.Forms.Label
    Friend WithEvents LblItemSoup As System.Windows.Forms.Label
    Friend WithEvents NumericPotato As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblPotato As System.Windows.Forms.Label
    Friend WithEvents NumericFlour As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblFlour As System.Windows.Forms.Label
    Friend WithEvents NumericMeat As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblMeat As System.Windows.Forms.Label
    Friend WithEvents NumericMilk As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblMilk As System.Windows.Forms.Label
    Friend WithEvents NumericSoup As System.Windows.Forms.NumericUpDown
    Friend WithEvents LblSoup As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btnOff As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents BtnOn As System.Windows.Forms.Button
    Friend WithEvents LblTotalCost As System.Windows.Forms.Label
    Friend WithEvents LblItemTotal As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblNumOfItems As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents BtnPrint As System.Windows.Forms.Button
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog

End Class

﻿Public Class Bill

    Const bread = 14.0
    Const Oil = 13.0
    Const Rice = 120.0
    Const Nyala = 80.0
    Const Beans = 12.0
    Const Soup = 36.0
    Const Milk = 10.0
    Const Meat = 26.0
    Const Flour = 140.0
    Const Potato = 60.0

    'Creating an Array to Find Total(Declare)

    Dim Item(10)
    
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click

        Dim Iexit As DialogResult = MessageBox.Show("Are you sure you want to leave", "Exting...", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If Iexit = Windows.Forms.DialogResult.Yes Then
            Application.Exit()
        Else
            Iexit = Windows.Forms.DialogResult.No
        End If

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

        Application.Exit()

    End Sub

    Private Sub Bill_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Off()

    End Sub

    Private Sub NumericBread_ValueChanged(sender As Object, e As EventArgs) Handles NumericBread.ValueChanged

        LblBread.Text = FormatCurrency(NumericBread.Value * bread)

    End Sub

    Private Sub NumericOil_ValueChanged(sender As Object, e As EventArgs) Handles NumericOil.ValueChanged

        LblOil.Text = FormatCurrency(NumericOil.Value * Oil)

    End Sub

    Private Sub NumericRice_ValueChanged(sender As Object, e As EventArgs) Handles NumericRice.ValueChanged

        LblRice.Text = FormatCurrency(NumericRice.Value * Rice)

    End Sub

    Private Sub NumericNyala_ValueChanged(sender As Object, e As EventArgs) Handles NumericNyala.ValueChanged

        LblNyala.Text = FormatCurrency(NumericNyala.Value * Nyala)

    End Sub

    Private Sub NumericBeans_ValueChanged(sender As Object, e As EventArgs) Handles NumericBeans.ValueChanged

        LblBeans.Text = FormatCurrency(NumericBeans.Value * Beans)

    End Sub

    Private Sub NumericSoup_ValueChanged(sender As Object, e As EventArgs) Handles NumericSoup.ValueChanged

        LblSoup.Text = FormatCurrency(NumericSoup.Value * Soup)

    End Sub

    Private Sub NumericMilk_ValueChanged(sender As Object, e As EventArgs) Handles NumericMilk.ValueChanged

        LblMilk.Text = FormatCurrency(NumericMilk.Value * Milk)

    End Sub

    Private Sub NumericMeat_ValueChanged(sender As Object, e As EventArgs) Handles NumericMeat.ValueChanged

        LblMeat.Text = FormatCurrency(NumericMeat.Value * Meat)

    End Sub

    Private Sub NumericFlour_ValueChanged(sender As Object, e As EventArgs) Handles NumericFlour.ValueChanged

        LblFlour.Text = FormatCurrency(NumericFlour.Value * Flour)

    End Sub

    Private Sub NumericPotato_ValueChanged(sender As Object, e As EventArgs) Handles NumericPotato.ValueChanged

        LblPotato.Text = FormatCurrency(NumericPotato.Value * Potato)


    End Sub

    Private Sub Off()

        'Switch Off System
        NumericBread.Enabled = False
        LblBread.Text = "R0.00"
        LblBread.Enabled = False

        NumericBeans.Enabled = False
        LblBeans.Text = "R0.00"
        LblBeans.Enabled = False

        NumericFlour.Enabled = False
        LblFlour.Text = "R0.00"
        LblFlour.Enabled = False

        NumericMeat.Enabled = False
        LblMeat.Text = "R0.00"
        LblMeat.Enabled = False

        NumericMilk.Enabled = False
        LblMilk.Text = "R0.00"
        LblMilk.Enabled = False

        NumericNyala.Enabled = False
        LblNyala.Text = "R0.00"
        LblNyala.Enabled = False

        NumericOil.Enabled = False
        LblOil.Text = "R0.00"
        LblOil.Enabled = False

        NumericPotato.Enabled = False
        LblPotato.Text = "R0.00"
        LblPotato.Enabled = False

        NumericBread.Enabled = False
        LblBread.Text = "R0.00"
        LblBread.Enabled = False

        NumericRice.Enabled = False
        LblRice.Text = "R0.00"
        LblRice.Enabled = False

        NumericSoup.Enabled = False
        LblSoup.Text = "R0.00"
        LblSoup.Enabled = False

        LblTotalCost.Enabled = False
        LblTotalCost.Text = "R0.00"

        lblNumOfItems.Enabled = False

        'buttons Off
        BtnExit.Enabled = False
        BtnTotal.Enabled = False
        BtnReset.Enabled = False
        BtnReceipt.Enabled = False
        BtnPrint.Enabled = False
        btnOff.Enabled = False
        RichTextBox1.Enabled = False

    End Sub
    Private Sub btnOff_Click(sender As Object, e As EventArgs) Handles btnOff.Click

        Off()

    End Sub

    Private Sub BtnOn_Click(sender As Object, e As EventArgs) Handles BtnOn.Click

        'Switch On System
        NumericBread.Enabled = True
        LblBread.Text = "R0.00"
        LblBread.Enabled = True

        NumericBeans.Enabled = True
        LblBeans.Text = "R0.00"
        LblBeans.Enabled = True

        NumericFlour.Enabled = True
        LblFlour.Text = "R0.00"
        LblFlour.Enabled = True

        NumericMeat.Enabled = True
        LblMeat.Text = "R0.00"
        LblMeat.Enabled = True

        NumericMilk.Enabled = True
        LblMilk.Text = "R0.00"
        LblMilk.Enabled = True

        NumericNyala.Enabled = True
        LblNyala.Text = "R0.00"
        LblNyala.Enabled = True

        NumericOil.Enabled = True
        LblOil.Text = "R0.00"
        LblOil.Enabled = True

        NumericPotato.Enabled = True
        LblPotato.Text = "R0.00"
        LblPotato.Enabled = True

        NumericBread.Enabled = True
        LblBread.Text = "R0.00"
        LblBread.Enabled = True

        NumericRice.Enabled = True
        LblRice.Text = "R0.00"
        LblRice.Enabled = True

        NumericSoup.Enabled = True
        LblSoup.Text = "R0.00"
        LblSoup.Enabled = True

        LblTotalCost.Enabled = True
        LblTotalCost.Text = "R0.00"

        lblNumOfItems.Enabled = True

        'buttons On
        BtnExit.Enabled = True
        BtnTotal.Enabled = True
        BtnReset.Enabled = True
        BtnReceipt.Enabled = True
        BtnPrint.Enabled = True
        btnOff.Enabled = True
        RichTextBox1.Enabled = True

    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        'Reset
        NumericBeans.Value = 0
        NumericBread.Value = 0
        NumericFlour.Value = 0
        NumericMeat.Value = 0
        NumericMilk.Value = 0
        NumericNyala.Value = 0
        NumericOil.Value = 0
        NumericPotato.Value = 0
        NumericRice.Value = 0
        NumericSoup.Value = 0
        LblTotalCost.Text = "R0.00"

    End Sub

    Private Sub BtnTotal_Click(sender As Object, e As EventArgs) Handles BtnTotal.Click

        Item(0) = NumericBread.Value * bread
        Item(1) = NumericOil.Value * Oil
        Item(2) = NumericRice.Value * Rice
        Item(3) = NumericNyala.Value * Nyala
        Item(4) = NumericBeans.Value * Beans
        Item(5) = NumericSoup.Value * Soup
        Item(6) = NumericMilk.Value * Milk
        Item(7) = NumericMeat.Value * Meat
        Item(8) = NumericFlour.Value * Flour
        Item(9) = NumericPotato.Value * Potato

        Item(10) = Item(0) + Item(1) + Item(2) + Item(3) + Item(4) + Item(5) + Item(6) + Item(7) + Item(8) + Item(9)
        LblTotalCost.Text = FormatCurrency(Item(10))


        'Incrementing the number of Items(Array)

        Dim Calc(10)

        Calc(0) = NumericBread.Value
        Calc(1) = NumericOil.Value
        Calc(2) = NumericRice.Value
        Calc(3) = NumericNyala.Value
        Calc(4) = NumericBeans.Value
        Calc(5) = NumericSoup.Value
        Calc(6) = NumericMilk.Value
        Calc(7) = NumericMeat.Value
        Calc(8) = NumericFlour.Value
        Calc(9) = NumericPotato.Value

        Calc(10) = Calc(0) + Calc(1) + Calc(2) + Calc(3) + Calc(4) + Calc(5) + Calc(6) + Calc(7) + Calc(8) + Calc(9)
        lblNumOfItems.Text = Calc(10)

    End Sub

    Private Sub BtnReceipt_Click(sender As Object, e As EventArgs) Handles BtnReceipt.Click

        RichTextBox1.Clear()
        RichTextBox1.AppendText(Label3.Text & vbTab & vbTab & Label11.Text & vbTab & Label7.Text & vbNewLine & vbNewLine) 'Headings

        RichTextBox1.AppendText(LblItemBread.Text & vbTab & vbTab & NumericBread.Value & vbTab & vbTab & LblBread.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemOil.Text & vbTab & vbTab & NumericOil.Value & vbTab & vbTab & LblOil.Text & vbTab & vbNewLine)
        RichTextBox1.AppendText(LblItemRice.Text & vbTab & vbTab & NumericRice.Value & vbTab & vbTab & LblRice.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemNyala.Text & vbTab & vbTab & NumericNyala.Value & vbTab & vbTab & LblNyala.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemBeans.Text & vbTab & vbTab & NumericBeans.Value & vbTab & vbTab & LblBeans.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemSoup.Text & vbTab & vbTab & NumericSoup.Value & vbTab & vbTab & LblSoup.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemMilk.Text & vbTab & vbTab & NumericMilk.Value & vbTab & vbTab & LblMilk.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemMeat.Text & vbTab & vbTab & NumericMeat.Value & vbTab & vbTab & LblMeat.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemFlour.Text & vbTab & vbTab & NumericFlour.Value & vbTab & vbTab & LblFlour.Text & vbNewLine)
        RichTextBox1.AppendText(LblItemPotato.Text & vbTab & vbTab & NumericPotato.Value & vbTab & vbTab & LblPotato.Text & vbNewLine & vbNewLine)

        RichTextBox1.AppendText(LblItemTotal.Text & vbTab & lblNumOfItems.Text & vbTab & vbTab & LblTotalCost.Text & vbNewLine) 'Total Cost

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

        Me.Hide()
        Dim login = New LoginForm
        login.ShowDialog()

    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click

        PrintPreviewDialog1.Show()

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Try

            e.Graphics.DrawString("Receipt", New Font("Century Gothic", 25), Brushes.DarkGreen, 180, 40)
            e.Graphics.DrawString("*******Cost Of Items*******", New Font("Arial", 20), Brushes.Crimson, 330, 100)
            e.Graphics.DrawString(RichTextBox1.Text, New Font("Century Gothic", 20), Brushes.Black, 150, 190)

            e.Graphics.DrawString("", New Font("Century Gothic", 15), Brushes.DarkGreen, 150, 500)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub PrintPreviewDialog1_Load(sender As Object, e As EventArgs) Handles PrintPreviewDialog1.Load

    End Sub
End Class
